<?php

  include('conn.php');
  $data = $_SERVER['QUERY_STRING'];
  $data = substr($data,2);
  //$array = array();

  $sql = "select Title,Description,UpCount,DownCount from feed where Feed_ID = $data"; 

  $result = mysqli_query($conn,$sql);
  $row = mysqli_fetch_assoc($results);
  //$feedid = $row["Feed_ID"];
   $title = $row["Title"];
   $desc = $row["Description"];
   $up = $row["UpCount"];
   $down = $row["DownCount"];
   
     //   $date = $row["Date"];

?>

<!DOCTYPE html>
<html>

<head></head>

<body>

  <h1> Tilte : <?php echo $title ?> </h1>
  <h3> Description : <?php $desc ?> </h3>
</body>



</html>











