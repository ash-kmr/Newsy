<?php
	$dbhost = 'localhost';
    $dbuser = 'root';
    $dbpass = 'mh20dj@9430';
	$dbname = 'csp';
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
   
    if(! $conn ) {
       die('Could not connect: ' . mysql_error());
    }
	
?>	
