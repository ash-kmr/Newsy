
<?php

include('DataExtraction.php');

/*
include("connection.php");

session_start();

//$_SERVER["REQUEST_METHOD"] = "GET";
if($_SERVER["REQUEST_METHOD"] == "POST"){
     //$error = "Hello";
  if($_POST['SignUp']){
  
      
  
  }
 if($_POST['Login']){  
   $username = $conn->escape_string($_POST['username']);
  // $username = $conn->mysqli_real_escape_string($user);
   
   $password = $conn->escape_string($_POST['password']);
   $email = $conn->escape_string($_POST['email']);
   $mobile = $conn->escape_string($_POST['mobile']);
   
  
   //$username = "sid23nahar";
   $sql = "select UserID from Authentication where UserID = '".$username."'"." and Password = '".$password."'";
   $result = $conn->query($sql);
   
   if($result->num_rows > 0){
      
      //session_register("username");
      $_SESSION['login_user'] = $username;
      //$error = "Welcome";
      //alert("Success");   
      header("location: welcome.php");

   }
   else
     $error = "Your Login Name or Password is invalid";
   
  }
}
else{
    
}
?>


<html>
   
   <head>
      <title>Login Page</title>
      
      <style type = "text/css">
         body {
            font-family:Arial, Helvetica, sans-serif;
            font-size:14px;
         }
         
         label {
            font-weight:bold;
            width:100px;
            font-size:14px;
         }
         
         .box {
            border:#666666 solid 1px;
         }
      </style>
      
   </head>
   
   <body bgcolor = "#FFFFFF">
	
      <div align = "center">
         <div style = "width:300px; border: solid 1px #333333; " align = "left">
            <div style = "background-color:#333333; color:#FFFFFF; padding:3px;"><b>Login</b></div>
				
            <div style = "margin:30px">
               
               <form action="" method = "post">
                  <label>UserName  :</label>
                        <input type = "text" name = "username" class = "box" required/><br/><br/>
                  
                  <label>Password  :</label>
                        <input type = "password" name = "password" class = "box" required/><br/><br/>
                  
                 
                  <input type = "submit" name ="Login" value = " Submit "/><br />
               </form>
               
               <form action="" method = "post">
                  <label>UserName  :</label>
                        <input type = "text" name = "username" class = "box" required/><br/><br/>
                  
                  <label>Password  :</label>
                        <input type = "password" name = "password" class = "box" required/><br/><br/>
                   
                  <label>Confirm Password  :</label>
                        <input type = "password" name = "passwordMatch" class = "box" required/><br/><br/>     
                  
                  <label>Email  :</label>
                        <input type = "text" name = "email" class = "box" required/><br/><br/>
                  
                  <label>Number  :</label>
                        <input type = "number" name = "mobile" class = "box" required/><br/><br/>
                  
                  <input type = "submit" name ="SignUp" value = " Submit "/><br />
               </form>
               <p><a href="forgot.php">Forgot Password?</a></p>
               <div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php echo $error; ?></div>
					
            </div>
				
         </div>
			
      </div>

   </body>
</html>
*/
?>
