<?php

  /*Run php to run python script each hour for extraction of file*/
  //include_once('Run.php');
  /*Require to Establish connection to database*/
  
  /*Get Contents of JSON file*/
$servername = "localhost";
$username = "root";
$passwd = "mh20dj@9430";
$dbname = "Newly";
  
$conn = mysqli_connect($servername,$username,$passwd,$dbname);
 
  $Json_Feed = file_get_contents('newsarticles.json',true);
  
  /*Decodeing JSON format as an associative array*/
  $Feed = json_decode($Json_Feed,true);

  /*Running lop through each article and inserting data into database*/
  foreach($Feed as $key=>$value){
  
        foreach($value as $key1=>$value1){
        
                //echo "$key1 => $value1\n";
               
               foreach($value1["articles"] as $article){
                      
                      
                      $sql ="";
                      $query = "";
                      $title = $article["title"];
                      str_replace("'", " ", $title);
                      str_replace('"', " ", $title);
                      $content = $article["text"];
                      str_replace('"', ' ', $content);
                      str_replace("'", " ", $content);
                      $Date = $article["published"];
                      //echo "$content---------------------------------";
                      //echo "$Date";
                      //$query = "('"."$title"."','"."$content"."')";
                      $sql = "Insert into feed(Title,Description, Date) values ('$title','$content','$Date')"; 
                      //echo "here";
                      $result = mysqli_query($conn, $sql);
                      
                      if ($result){
                        echo "Hello\n";
                      }else{
                        echo "not done";
                      }
//                      mysqli_close($conn);
                      //echo "$sql-------------------------------------\n";
                      /*
                      $result = mysqli_query($conn,"Select * from feed");
                      echo $result->num_rows;*/
               }
        }
  
  }
  
  function create($article){
  
                     
                      //$Date = date_create($Date);
                      $query = "('".$article["title"]."','".$article["published"]."','".$article["text"]."')";
                      $sql = "Insert into feed(Title,Date,Description) values ".$query; 
  
                      return $sql;
  }
  //echo $Feed["newsarticles"]["cnn"]["articles"][0]["title"];
 // echo $k;

?>

