<?php

  //$command = 'ls';
  //exec($command, $out, $status);
  $message = exec('ls *.json');
  //sprint_r($message);


?>
