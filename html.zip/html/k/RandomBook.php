<?php

include 'connection.php';

$sql = "SELECT ISBN,title,description from bookdescriptions order by rand() limit 1";

$result = $conn->query($sql);
if($result->num_rows == 0)
  echo 'Failed';
else{

   while($row = $result->fetch_assoc()) {
        echo "ISBN: " . $row["ISBN"]. "</br>" . " - Tilte: " . $row["title"]. "</br>" . " " . $row["description"]. "<br>";
    }
}

?>
