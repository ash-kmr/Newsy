<?php

  include("connection.php");
  session_start();
  
  $user_check = $_SESSION['login_user'];

  $result = $conn->query("select UserID from Authentication where UserID = '$user_check' ");
  
  $login_session = $result->fetch_assoc();
  $login_session = $login_session['UserID'];
  
  if(!isset($_SESSION['login_user'])){
      header("location:login.php");
   }

?>



