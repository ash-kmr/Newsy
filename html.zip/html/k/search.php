<?php
   
   class deatils{
       public $ISBN;
       public $title;
   }
   
  include 'connection.php';
  header('Content-type: application/json');
  $data = $_SERVER['QUERY_STRING'];
  $data = substr($data,2);
  $array = array();
  
  $sql = "select ISBN,title,description from bookdescriptions";
  $result = $conn->query($sql);
  $sq = 'False';
  if($result->num_rows > 0){
   
    while($row = $result->fetch_assoc()){
         $desc = $row["description"];
      if (strpos($desc, $data) !== false) {
          $obj = new deatils();
          $obj->ISBN = $row["ISBN"];
          $obj->title = $row["title"];
          array_push($array,$obj);
      }    
    }
    
    }
  
  
  else
    $sq = 'False Not proper sql';
 
  
  echo json_encode($array);

?>
