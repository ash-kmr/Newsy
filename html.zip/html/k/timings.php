<?php
  
  $servername = "localhost";
  $username = "root";
  $passwd = "mh20dj@9430";
  $dbname = "Bookings";
  $conn = new mysqli($servername,$username,$passwd,$dbname);
  
  if($conn->connect_error){
    die("Connection failed : " . $conn->connect_error);
  }
  else{
  

     header('Content-type: application/json');
     $data = $_SERVER['QUERY_STRING'];
     $data = substr($data,2);
     $v = date('l',strtotime($data));
     $arr = array();
     $sql = "select * from TimeTable where day = '".$v."'";
      $result = $conn->query($sql);
     if($result->num_rows > 0){
   
        while($row = $result->fetch_assoc()){
           $desc = $row["Timings"];
           array_push($arr,$desc);
        }
        
        echo json_encode($arr);
    
    }
    
    else
       echo json_encode($v);
       //echo json_encode($v);
   }   
  
?>
