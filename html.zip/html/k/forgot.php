<?php

  include("connection.php");
  require("/home/siddharth/PHPMailer-master/src/PHPMailer.php");
  require("/home/siddharth/PHPMailer-master/src/SMTP.php");
  require("/home/siddharth/PHPMailer-master/src/Exception.php");
  //require_once "vendor/autoload.php";
  error_reporting(E_ALL);
  ini_set('display_errors', '1');
  session_start();
  $error ="";
  if($_SERVER["REQUEST_METHOD"] == "POST"){
  
     $username = $conn->escape_string($_POST['username']);
  // $username = $conn->mysqli_real_escape_string($user);
     $email = $conn->escape_string($_POST['email']); 
     $sql = "select * from Authentication where UserId = '".$username."'"." and Email = '".$email."'";
     $result = $conn->query($sql);
     if($result->num_rows > 0){
     
        $list = $result->fetch_assoc();
        $pass = $list['Password'];
        /*
        $to = $email;
        $subject = 'Change of Password';
        $body = 'This is Your password : $pass';
        //$header = "From: 2016csb1043@iitrpr.ac.in";
       
        //$to = $this->post_data['register-email'];
         
        if(mail($to,$subject,$body))
          $error = "Email Sent";
        else
          $error = "Email not sent ";
        */
        
       $mail = new PHPMailer\PHPMailer\PHPMailer();
        //Enable SMTP debugging. 
        
         $mail->SMTPDebug = 3;                               
       //Set PHPMailer to use SMTP.
        $mail->isSMTP();            
        //Set SMTP host name                          
        $mail->Host = "smtp.gmail.com";
        
        //Set this to true if SMTP host requires authentication to send email
        $mail->SMTPAuth = true;  
                                
        //Provide username and password
        
        $mail->Username = "sid23nahar@gmail.com";
        $mail->Password = "MH20dj@9430";
                                  
        //If SMTP requires TLS encryption then set it
        $mail->SMTPSecure = "ssl";                           
        //Set TCP port to connect to 
        
        $mail->Port = 465; 
        $mail->From = "sid23nahar@gmail.com";
        $mail->FromName = "Siddharth Nahar";
        $mail->addAddress("sid23nahar@gmail.com", "Siddharth Nahar");

        $mail->isHTML(true);

        $mail->Subject = "Samplet";
        $mail->Body = "<i>Mail body in HTML</i>";
        $mail->AltBody = "This is the plain text version of the email content";
        if(!$mail->send()) 
        {
            echo "Mailer Error: " . $mail->ErrorInfo;
        } 
        else 
        {
            echo "Message has been sent successfully";
        }
        
     }else{
     
        $error = "Invalid Username or Email";
     }
  }


?>

<html>
   
   <head>
      <title>Login Page</title>
      
      <style type = "text/css">
         body {
            font-family:Arial, Helvetica, sans-serif;
            font-size:14px;
         }
         
         label {
            font-weight:bold;
            width:100px;
            font-size:14px;
         }
         
         .box {
            border:#666666 solid 1px;
         }
      </style>
      
   </head>
   
   <body bgcolor = "#FFFFFF">
	
      <div align = "center">
         <div style = "width:300px; border: solid 1px #333333; " align = "left">
            <div style = "background-color:#333333; color:#FFFFFF; padding:3px;"><b>Login</b></div>
				
            <div style = "margin:30px">
               
               <form action="" method = "post">
                  <label>UserName  :</label>
                        <input type = "text" name = "username" class = "box" required/><br/><br/>
                  
                 
                  
                  <label>Registered Email  :</label>
                        <input type = "text" name = "email" class = "box" required/><br/><br/>
                  
                  <input type = "submit" name ="Submit" value = " Submit "/><br />
               </form>
               
               <div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php echo $error; ?></div>
					
            </div>
				
         </div>
			
      </div>

   </body>
</html>
