<?php

  $servername = "localhost";
  $username = "root";
  $passwd = "mh20dj@9430";
  $dbname = "Newly";
  
  $conn = mysqli_connect($servername,$username,$passwd,$dbname);
 

?>

