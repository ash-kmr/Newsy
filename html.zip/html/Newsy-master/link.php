<?php

  include('conn.php');
  $data = $_SERVER['QUERY_STRING'];
  $data = substr($data,2);
  //$array = array();

  $sql = "select Title,Description,UpCount,DownCount from feed where Feed_ID = $data"; 

  $result = mysqli_query($conn,$sql);
  $row = mysqli_fetch_assoc($results);
  //$feedid = $row["Feed_ID"];
   $title = $row["Title"];
   $desc = $row["Description"];
   $up = $row["UpCount"];
   $down = $row["DownCount"];
   
     //   $date = $row["Date"];

?>

<!DOCTYPE html>
<html>

<head></head>

<body>

  <h1> Tilte : <?php echo $title ?> </h1>
  <h3> Description : <?php $desc ?> </h3>
  <p><i onclick="myFunction_up(this)" class="fa fa-thumbs-up">  <?php   ?></i>
  <i onclick="myFunction_down(this)" class="fa fa-thumbs-down"></i>

  <script>

 function myFunction_up(x) {
 $a=1;
 if($a%2==1)
 {$(x).css("color", "blue");
  $a=$a+1;
 }
 else
 {$(x).css("color", "dark");
  $a=$a+1;

}
}

function myFunction_down(x) {
  if($b==1)
 {$(x).css("color", "blue");
  $b=2;
 }
 else
 {$(x).css("color", "dark");
  $b=1;
 }  


}
</script>
</body>



</html>











